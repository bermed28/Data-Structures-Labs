package ciic4020.lab5.strategiesClasses;

import java.util.ArrayList;
import java.util.Comparator;

public class SelectionSort<E> extends AbstractSortingStrategy<E> {

	public SelectionSort(Comparator<E> cmp) { 
		super("SelectionSort", cmp); 
	}
	
	@Override
	public void sortList(ArrayList<E> dataSet) {
		int n = dataSet.size(); 
		E smallest = null;
		/* TODO ADD CODE HERE FOLLOWING PSEUDOCODE
		 * 
		 * Use a simple for loop to find the smallest value in the desired range
		 * 
		 * To compare two values in dataSet, use something like:
		 *    if (cmp.compare(dataSet.get(j), dataSet.get(sm)) < 0)
		 * To swap, use something like:
		 *    SortingUtils.swapListElements(dataSet, sm, i); 
		 *    assuming that sm and i are indexes within dataSet.
		 */
		for (int i = 0 ; i < n; i++) {
			smallest = dataSet.get(i);
			for (int j = i + 1; j < n; j++) {
				if (cmp.compare(dataSet.get(j), smallest) < 0) {
					smallest = dataSet.get(j);
					SortingUtils.swapListElements(dataSet, j, i);
				}
			}
		}
	}

}